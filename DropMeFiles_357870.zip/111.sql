﻿1 модуль

CREATE DATABASE BD;
GO
USE BD;
GO
CREATE TABLE Users (userID VARCHAR(10), pswd VARCHAR(256));
GO
DECLARE @i int = 1;
DECLARE @userName NVARCHAR(10) = '';
DECLARE @pswdRandom NVARCHAR(5) = '';
DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @databaseName NVARCHAR(10) = '';
WHILE @i <= 10
BEGIN
	set @userName = 'user' + CAST(@i AS nvarchar(2));
	set @databaseName = 'BD' + CAST(@i AS nvarchar(2));
	set @pswdRandom = LEFT(CONVERT(NVARCHAR(100), NEWID()), 5);
	EXEC('CREATE DATABASE ' + @databaseName);
	INSERT INTO Users values(@userName, @pswdRandom);
	set @sql = N'CREATE LOGIN ' + QUOTENAME(@userName) + ' WITH PASSWORD = ''' + @pswdRandom + ''', CHECK_POLICY = OFF 
				USE ' + QUOTENAME(@databaseName) + ';
				CREATE USER ' + QUOTENAME(@userName) + ' FOR LOGIN ' + QUOTENAME(@userName) + ';
				GRANT CONNECT TO ' + QUOTENAME(@userName) + ';
				GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO ' + QUOTENAME(@userName) + ';';

	EXEC sp_executesql @sql;
	DECLARE @denyBDSQL NVARCHAR(MAX) = N'USE master;
										DENY CREATE ANY DATABASE TO ' + QUOTENAME(@userName) + ';'
	exec sp_executesql @denyBDSQL;
	set @i += 1;
END
2 модуль
--пассворо
use BD;
go
create master key encryption by password = 'passwOrd123'
open master key decryption by password = 'passwOrd123';
create certificate UserCertificate with subject = 'UserCertificate';
create symmetric key UserSymmetricKey with algorithm = aes_256 encryption by certificate UserCertificate;
close master key;
go

22
--Шифрует пароли 
use BD;
GO
open symmetric key UserSymmetricKey decryption by certificate UserCertificate;
update Users set pswd = ENCRYPTBYKEY(KEY_GUID('UserSymmetricKey'), CONVERT(varbinary(MAX), pswd))
close symmetric key UserSymmetricKey;
go

222
--Показывает, как расшифровать пароли
use BD;
go
open symmetric key UserSymmetricKey decryption by certificate UserCertificate;
select userID, pswd, CONVERT(varchar(50), DECRYPTBYKEY(convert(varbinary(max), pswd))) as decrypted_pswd
from Users;
close symmetric key UserSymmetricKey;
go

3 моддуль
--бекап
use master;
go
backup database BD TO DISK = 'C:\Users\stuck\Desktop\это я\BD.BAK'
GO
--не бекап
USE master;
go
alter database BD set single_user with rollback immediate;
restore database BD from disk = 'C:\Users\stuck\Desktop\это я\BD.BAK';
with move 'BD' TO 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\BD.mdf',
move 'BD_log' TO 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Backup\BD_log.ldf',
replace;
go

4 module
use BD;
go

CREATE TABLE Clients (
    id NVARCHAR(5) PRIMARY KEY,
    name NVARCHAR(50),
    phone NVARCHAR(20)
);

CREATE TABLE Materials (
    id INT IDENTITY PRIMARY KEY,
    name NVARCHAR(30),
    price DECIMAL(8,2)
);

CREATE TABLE Products (
    id INT IDENTITY PRIMARY KEY,
    name NVARCHAR(50),
    price DECIMAL(8,2)
);

CREATE TABLE Specs (
    id INT IDENTITY PRIMARY KEY,
    productId INT FOREIGN KEY REFERENCES Products(id),
    materialId INT FOREIGN KEY REFERENCES Materials(id),
    count DECIMAL(6,2)
);

CREATE TABLE Orders (
    id INT IDENTITY PRIMARY KEY,
    num INT,
    date DATE,
    clientId NVARCHAR(5) FOREIGN KEY REFERENCES Clients(id)
);

CREATE TABLE OrderItems (
    id INT IDENTITY PRIMARY KEY,
    orderId INT FOREIGN KEY REFERENCES Orders(id),
    productId INT FOREIGN KEY REFERENCES Products(id),
    qty INT,
    sum DECIMAL(10,2)
);

CREATE TABLE Production (
    id INT IDENTITY PRIMARY KEY,
    num INT,
    date DATE,
    productId INT FOREIGN KEY REFERENCES Products(id),
    qty DECIMAL(8,2)
);

CREATE TABLE ProdMaterials (
    id INT IDENTITY PRIMARY KEY,
    prodId INT FOREIGN KEY REFERENCES Production(id),
    materialId INT FOREIGN KEY REFERENCES Materials(id),
    count DECIMAL(8,2)
);

INSERT INTO Clients VALUES ('C001', 'ООО Ромашка', '111-1111');
INSERT INTO Clients VALUES ('C002', 'ИП Иванов', '222-2222');
INSERT INTO Clients VALUES ('C003', 'ООО Весна', '333-3333');

INSERT INTO Materials VALUES ('Молоко', 50);
INSERT INTO Materials VALUES ('Закваска', 100);
INSERT INTO Materials VALUES ('Дерево', 200);

INSERT INTO Products VALUES ('Кефир', 80);
INSERT INTO Products VALUES ('Сметана', 150);
INSERT INTO Products VALUES ('Стол', 3000);

INSERT INTO Specs VALUES (1, 1, 0.9);
INSERT INTO Specs VALUES (2, 2, 0.07);
INSERT INTO Specs VALUES (3, 3, 2.0);

INSERT INTO Orders VALUES (101, '2025-06-01', 'C001');
INSERT INTO Orders VALUES (102, '2025-06-05', 'C002');
INSERT INTO Orders VALUES (103, '2025-06-10', 'C003');

INSERT INTO OrderItems VALUES (1, 1, 10, 800);
INSERT INTO OrderItems VALUES (1, 2, 5, 750);
INSERT INTO OrderItems VALUES (2, 3, 2, 6000);

INSERT INTO Production VALUES (201, '2025-06-02', 1, 100);
INSERT INTO Production VALUES (202, '2025-06-03', 2, 50);
INSERT INTO Production VALUES (203, '2025-06-04', 3, 10);

INSERT INTO ProdMaterials VALUES (1, 1, 90);
INSERT INTO ProdMaterials VALUES (2, 2, 3.5);
INSERT INTO ProdMaterials VALUES (3, 3, 20);

module 5

USE BD;
GO
CREATE PROCEDURE ReportPeriod
    @date_start DATE,
    @date_end DATE
AS
BEGIN
    SELECT 
        c.name AS Заказчик,
        COUNT(DISTINCT o.id) AS [Кол-во заказов],
        SUM(oi.qty) AS [Кол-во продукции],
        SUM(oi.sum) AS [Общая сумма]
    FROM Orders o
    JOIN Clients c ON o.clientId = c.id
    JOIN OrderItems oi ON o.id = oi.orderId
    WHERE o.date BETWEEN @date_start AND @date_end
    GROUP BY c.name;
END
GO
EXEC ReportPeriod '2025-01-01', '2025-12-31';
ALTER TABLE Orders ADD total_sum DECIMAL(12,2) DEFAULT 0;
GO

CREATE TRIGGER CalculateOrderTotal
ON OrderItems
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    UPDATE Orders
    SET total_sum = (
        SELECT ISNULL(SUM(sum), 0)
        FROM OrderItems
        WHERE orderId = Orders.id
    );
END
GO

модуль 6

USE BD;
GO
DECLARE @Year  INT = 2025;
DECLARE @Month INT = 5;                
DECLARE @MonthName NVARCHAR(15) = 
    (SELECT DATENAME(MONTH, DATEFROMPARTS(@Year, @Month, 1)));

DECLARE @ArchiveTableName NVARCHAR(50) = 'Orders_' + LOWER(@MonthName) + CAST(@Year AS NVARCHAR(4));
DECLARE @ArchiveItemsTableName NVARCHAR(50) = 'OrderItems_' + LOWER(@MonthName) + CAST(@Year AS NVARCHAR(4));
DECLARE @SQL NVARCHAR(MAX);
PRINT 'Создаётся архивная таблица: ' + @ArchiveTableName;
PRINT 'За период: ' + @MonthName + ' ' + CAST(@Year AS NVARCHAR(4));
GO
DECLARE @Year2  INT = 2025;
DECLARE @Month2 INT = 5;
DECLARE @MonthName2 NVARCHAR(15) = (SELECT DATENAME(MONTH, DATEFROMPARTS(@Year2, @Month2, 1)));
DECLARE @ArchiveTableName2 NVARCHAR(50) = 'Orders_' + LOWER(@MonthName2) + CAST(@Year2 AS NVARCHAR(4));
DECLARE @ArchiveItemsTableName2 NVARCHAR(50) = 'OrderItems_' + LOWER(@MonthName2) + CAST(@Year2 AS NVARCHAR(4));

SET @SQL = '
    SELECT * 
    INTO ' + @ArchiveTableName2 + '
    FROM Orders 
    WHERE YEAR(date) = ' + CAST(@Year2 AS NVARCHAR(4)) + 
    ' AND MONTH(date) = ' + CAST(@Month2 AS NVARCHAR(2)) + ';
    
    SELECT * 
    INTO ' + @ArchiveItemsTableName2 + '
    FROM OrderItems 
    WHERE orderId IN (SELECT id FROM Orders 
                      WHERE YEAR(date) = ' + CAST(@Year2 AS NVARCHAR(4)) + 
    ' AND MONTH(date) = ' + CAST(@Month2 AS NVARCHAR(2)) + ');
'
EXEC sp_executesql @SQL;
DELETE FROM OrderItems 
WHERE orderId IN (SELECT id FROM Orders 
                  WHERE YEAR(date) = @Year AND MONTH(date) = @Month);
DELETE FROM Orders 
WHERE YEAR(date) = @Year AND MONTH(date) = @Month;

PRINT 'Архивация успешно завершена. Данные перенесены в таблицы:';
PRINT '   → ' + @ArchiveTableName2;
PRINT '   → ' + @ArchiveItemsTableName2;
GO
модуль 7 
import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc
from decimal import Decimal

CONN = ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost;"
        "DATABASE=BD;Trusted_Connection=yes;")
class App:
    def __init__(self, root):
        self.root = root
        root.title("Анализ заказов")
        root.geometry("950x600")
        try:
            self.conn = pyodbc.connect(CONN)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e)); root.destroy(); return
        self.ui()
        self.load_clients()
        self.load()
    def ui(self):
        top = tk.Frame(self.root, pady=10); top.pack(fill=tk.X, padx=10)

        tk.Label(top, text="Сортировать:").grid(row=0, column=0)
        self.sf = ttk.Combobox(top, values=["date", "client", "total"],
                               state="readonly", width=10)
        self.sf.current(0); self.sf.grid(row=0, column=1, padx=5)
        self.so = tk.StringVar(value="ASC")
        tk.Radiobutton(top, text="↑", variable=self.so, value="ASC",
                       command=self.load).grid(row=0, column=2)
        tk.Radiobutton(top, text="↓", variable=self.so, value="DESC",
                       command=self.load).grid(row=0, column=3)
        tk.Label(top, text="Клиент:").grid(row=1, column=0, pady=5)
        self.cc = ttk.Combobox(top, state="readonly", width=28)
        self.cc.grid(row=1, column=1, columnspan=2)
        tk.Button(top, text="Фильтр", command=self.filter).grid(row=1, column=3, padx=5)
        tk.Button(top, text="Все", command=self.load).grid(row=1, column=4)
        tk.Label(top, text="Поиск:").grid(row=2, column=0, pady=5)
        self.se = tk.Entry(top, width=30); self.se.grid(row=2, column=1, columnspan=2, sticky="w")
        tk.Button(top, text="Найти", command=self.search).grid(row=2, column=3, padx=5)
        tk.Button(top, text="Сброс", command=self.clear).grid(row=2, column=4)
        cols = ("Дата", "Клиент", "Телефон", "Сумма")
        self.tv = ttk.Treeview(self.root, columns=cols, show="headings")
        for c in cols:
            self.tv.heading(c, text=c); self.tv.column(c, width=180, anchor="center")
        self.tv.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.tv.tag_configure("f", background="yellow")
        bot = tk.Frame(self.root); bot.pack(fill=tk.X, padx=10, pady=5)
        self.lc = tk.Label(bot, text="Заказов: 0", font=("Arial", 11, "bold"))
        self.lc.pack(side=tk.LEFT, padx=20)
        self.ls = tk.Label(bot, text="Сумма: 0.00", font=("Arial", 11, "bold"))
        self.ls.pack(side=tk.LEFT, padx=20)
    def load_clients(self):
        try:
            self.clients = self.conn.cursor().execute(
                "SELECT id, name FROM Clients ORDER BY name").fetchall()
            self.cc["values"] = [f"{c.id} — {c.name}" for c in self.clients]
            if self.clients: self.cc.current(0)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))
    def load(self, cid=None):
        try:
            m = {"date": "o.date", "client": "c.name", "total": "total"}
            sql = f"""SELECT o.date, c.name client, c.phone,
                      ISNULL(SUM(oi.sum),0) total
                      FROM Orders o JOIN Clients c ON c.id=o.clientId
                      LEFT JOIN OrderItems oi ON oi.orderId=o.id
                      {"WHERE o.clientId=?" if cid else ""}
                      GROUP BY o.id, o.date, c.name, c.phone
                      ORDER BY {m[self.sf.get()]} {self.so.get()}"""
            cur = self.conn.cursor()
            cur.execute(sql, cid) if cid else cur.execute(sql)
            self.fill(cur.fetchall())
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))
    def fill(self, rows):
        self.tv.delete(*self.tv.get_children())
        s = Decimal(0)
        for r in rows:
            self.tv.insert("", tk.END, values=(r.date, r.client, r.phone, f"{r.total:.2f}"))
            s += r.total or 0
        self.lc.config(text=f"Заказов: {len(rows)}")
        self.ls.config(text=f"Сумма: {s:.2f}")
    def filter(self):
        try:
            i = self.cc.current()
            if i >= 0: self.load(self.clients[i].id)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def search(self):
        q = self.se.get().strip().lower()
        self.clear()
        if not q: return
        n = 0
        for it in self.tv.get_children():
            if any(q in str(v).lower() for v in self.tv.item(it, "values")):
                self.tv.item(it, tags=("f",)); n += 1
        if not n: messagebox.showinfo("Поиск", "Не найдено")
    def clear(self):
        for it in self.tv.get_children():
            self.tv.item(it, tags=())
if __name__ == "__main__":
    try:
        r = tk.Tk(); App(r); r.mainloop()
    except Exception as e:
        messagebox.showerror("Ошибка", str(e))